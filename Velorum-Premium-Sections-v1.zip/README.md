# Velorum Premium Sections Pack

This folder contains the complete refactored Liquid sections for Velorum. They are designed to be "Plug & Play" on any Shopify 2.0 theme.

## 📂 Folder Structure
- `sections/`: Contains the 5 main landing page sections.
- `snippets/`: Contains `velorum-assets.liquid` for loading premium fonts.

## 🚀 Installation Instructions

### Step 1: Upload Assets
1. Go to your Shopify Admin > **Online Store** > **Themes**.
2. Click **Edit Code**.
3. Under the **Snippets** folder, click **Add a new snippet**. Name it `velorum-assets`.
4. Paste the content of `snippets/velorum-assets.liquid` into it.

### Step 2: Load Fonts
1. Open your `layout/theme.liquid` file.
2. Find the `<head>` tag.
3. Just before the `</head>` closing tag, add this line:
   `{% render 'velorum-assets' %}`

### Step 3: Add Sections
1. For each file in the `sections/` folder:
   - Click **Add a new section** under the **Sections** folder.
   - Name it exactly as the file (e.g., `velorum-hero`).
   - Paste the code from the corresponding `.liquid` file.

### Step 4: Build Your Page
1. Go to **Online Store** > **Customize**.
2. Add the sections to your homepage or a new landing page.
3. Look for the "Velorum" prefix in the section list.

---
**Tip:** All sections are fully customizable. You can change colors, text, and images directly in the sidebar without touching the code.
